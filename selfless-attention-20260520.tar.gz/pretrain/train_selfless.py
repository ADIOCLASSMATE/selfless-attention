import os
import random
import re
import sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["TOKENIZERS_PARALLELISM"] = "true"
import json
import logging
import math
import shutil
import time
from pathlib import Path
from typing import Union

from omegaconf import OmegaConf
import torch
from torch.optim import AdamW
import torch.nn.functional as F


from transformers import AutoModelForCausalLM, AutoTokenizer, AutoConfig
from accelerate import Accelerator
from accelerate.logging import get_logger
from accelerate.utils import DistributedType, set_seed

from utils.dataset_utils import get_dataloaders
from utils.diffusion_utils import DiffusionLanguage
from utils.wsd_schedule import get_wsd_schedule
from models.logging import set_verbosity_info, set_verbosity_error

from utils.utils import get_config, flatten_omega_conf, get_selfless_mask, get_selfless_ar_mask, load_model_tokenizer, log_grad_norm, AverageMeter, save_checkpoint, save_hf_model

logger = get_logger(__name__, log_level="INFO")


def main():
    #########################
    #      SETUP Config     #
    #########################
    config = get_config()
        
    total_batch_size_per_gpu = config.training.batch_size
    
    config.experiment.output_dir = os.path.join(config.experiment.output_dir, config.experiment.project)
    config.experiment.logging_dir = os.path.join(config.experiment.output_dir, "logs")
    
    #########################
    # SETUP Accelerator     #
    #########################
    num_processes = int(os.environ.get("WORLD_SIZE", 1))
    assert num_processes != -1
    accelerator = Accelerator(
        gradient_accumulation_steps=((config.training.total_batch_size // config.training.batch_size) // num_processes),
        mixed_precision=config.training.mixed_precision,
        log_with="wandb",
        project_dir=config.experiment.logging_dir,
        step_scheduler_with_optimizer=config.training.step_scheduler_with_optimizer,
    )
    
    if accelerator.distributed_type == DistributedType.DEEPSPEED:
        accelerator.state.deepspeed_plugin.deepspeed_config["train_micro_batch_size_per_gpu"] = (
            total_batch_size_per_gpu
        )
        accelerator.state.deepspeed_plugin.deepspeed_config["gradient_accumulation_steps"] = (
            accelerator.gradient_accumulation_steps
        )

    #####################################
    # SETUP LOGGING, SEED and CONFIG    #
    #####################################
    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO,
    )
    logger.info(accelerator.state, main_process_only=False)
    if accelerator.is_local_main_process:
        set_verbosity_info()
    else:
        set_verbosity_error()

    # Initialize trackers
    if accelerator.is_main_process:
        log_config = {k: v for k, v in flatten_omega_conf(config, resolve=True)}
        log_config.pop("experiment.resume_from_checkpoint", None)

        accelerator.init_trackers(
            config.experiment.wandb_project,
            config=log_config,
            init_kwargs={"wandb": {"name": config.experiment.project}},
        )

    # Set training seed
    if config.training.seed is not None:
        set_seed(config.training.seed, device_specific=True)

    #########################
    # MODELS and TOKENIZER  #
    #########################
    logger.info("Loading tokenizer and model")
    model, tokenizer = load_model_tokenizer(config=config, logger=logger)
    
    diff_lm = DiffusionLanguage(mask_token_id=model.config.mask_token_id, config=config)
    
    ##################################
    #   Optimizer and LR scheduler   #
    ##################################
    optimizer_config = config.optimizer.params

    # No decay on bias and layernorm
    no_decay = ["bias", "layer_norm.weight", "ln_f.weight", "wte.weight"]
    optimizer_grouped_parameters = [
        {
            "params": [p for n, p in model.named_parameters() if
                       p.requires_grad and not any(nd in n for nd in no_decay)],
            "weight_decay": optimizer_config.weight_decay,
        },
        {
            "params": [p for n, p in model.named_parameters() if
                       p.requires_grad and any(nd in n for nd in no_decay)],
            "weight_decay": 0.0,
        },
    ]

    optimizer_type = config.optimizer.name
    if optimizer_type == "adamw":
        optimizer = AdamW(
            optimizer_grouped_parameters,
            lr=optimizer_config.learning_rate,
            betas=(optimizer_config.beta1, optimizer_config.beta2),
            weight_decay=optimizer_config.weight_decay,
            eps=optimizer_config.epsilon,
        )
    else:
        raise ValueError(f"Optimizer {optimizer_type} not supported")

    lr_scheduler = get_wsd_schedule(
        optimizer=optimizer,
        num_warmup_steps=config.lr_scheduler.params.warmup_steps,
        num_decay_steps=config.lr_scheduler.params.decay_steps,
        num_training_steps=config.training.max_train_steps,
        min_lr_ratio=config.lr_scheduler.params.min_lr_scale
    )

    ##################################
    #         DATALOADER             #
    ##################################
    logger.info("Creating dataloaders and lr_scheduler")

    seq_len = config.dataset.preprocessing.max_seq_length
    
    train_dataloader, val_dataloader = get_dataloaders(config, tokenizer)

    ##################################
    #       Prepare accelerator     #
    ##################################
    logger.info("Preparing model, optimizer and dataloaders")
    model, optimizer, train_dataloader, val_dataloader, lr_scheduler = accelerator.prepare(model, optimizer, train_dataloader, val_dataloader, lr_scheduler)

    ##################################
    #       MODEL RESUME         #
    ##################################
    global_step = 0
    resume_step = 0
    resume_checkpoint_dir = None

    if config.experiment.resume_from_checkpoint is not None:
        candidate_path = Path(config.experiment.resume_from_checkpoint)
        if candidate_path.exists():
            resume_checkpoint_dir = candidate_path
        else:
            logger.warning(f"Specified checkpoint not found: {candidate_path}")

    if resume_checkpoint_dir and resume_checkpoint_dir.exists():
        logger.info(f"Resuming training from checkpoint: {resume_checkpoint_dir}")
        
        # 加载模型权重、优化器状态、RNG 状态
        accelerator.load_state(resume_checkpoint_dir)
        
        metadata_file = resume_checkpoint_dir / "metadata.json"
        if metadata_file.exists():
            with open(metadata_file, "r") as f:
                metadata = json.load(f)
            resume_step = metadata.get("global_step", 0)
        else:
            logger.error(f"Error loading metadata from {metadata_file}")
        
        global_step = resume_step
        logger.info(f"Resumed at global_step={global_step}")

    else:
        logger.warning("No valid checkpoint found or specified, starting fresh training.")
        global_step = 0
        resume_step = 0

    ##################################
    #             Training           #
    ##################################
    total_batch_size = (
        total_batch_size_per_gpu
        * accelerator.num_processes * accelerator.gradient_accumulation_steps
    )
    logger.info("***** Running dllm pretraining *****")
    logger.info(f"  Num training steps = {config.training.max_train_steps}")
    logger.info(f"  Instantaneous batch size per device = {total_batch_size_per_gpu}")
    logger.info(f"  Total train batch size (w. parallel, distributed & accumulation) = {total_batch_size}")
    logger.info(f"  Gradient Accumulation steps = {accelerator.gradient_accumulation_steps}")
    logger.info(f"  mask_token_id: {config.model.mask_token_id}")
    
    if accelerator.is_main_process:
        os.makedirs(config.experiment.output_dir, exist_ok=True)
        config_path = Path(config.experiment.output_dir) / "config.yaml"
        logging.info(f"Saving config to {config_path}")
        OmegaConf.save(config, config_path)

    batch_time_m = AverageMeter()
    data_time_m = AverageMeter()
    end = time.time()
    batches_to_skip = 0
    if resume_step > 0:
        batches_to_skip = resume_step * accelerator.gradient_accumulation_steps
        logger.info(f"Resuming from step {resume_step}, skipping {batches_to_skip} batches...")
        train_dataloader = accelerator.skip_first_batches(train_dataloader, batches_to_skip)

    model.train()

    train_iter = iter(train_dataloader)

    while global_step < config.training.max_train_steps:
        try:
            batch = next(train_iter)
        except StopIteration:
            # 一个 epoch 跑完了，重新来
            train_iter = iter(train_dataloader)
            batch = next(train_iter)
        
        # *-------*-------*-------*-------*-------*-------*
        # Data Processing
        # *-------*-------*-------*-------*-------*-------*
        text_ids = batch["input_ids"][:, :-1].contiguous() # 与自回归训练token数量完全对齐
        B, L = text_ids.shape

        t_sample, v_sample = diff_lm.sample_v(text_ids)
        t_1 = t_sample[0,0].item()
    
        v_sample = v_sample.to(accelerator.device)
        diffusion_attention_mask = get_selfless_mask(v_sample=v_sample, seq_len=L, device=accelerator.device)
        del t_sample, v_sample
        
        # 仅在调试时打印一次
        if global_step == 0 and accelerator.is_main_process:
            logger.info(f"Input ids shape: {text_ids.shape}")

        # *-------*-------*-------*-------*-------*-------*
        # Forward & Backward
        # *-------*-------*-------*-------*-------*-------*
        with accelerator.accumulate(model):
            loss = model(
                X0_input_ids=text_ids,
                labels=text_ids,
                attention_mask=diffusion_attention_mask,
            ).loss
            
            accelerator.backward(loss)

            if accelerator.sync_gradients:
                if config.training.max_grad_norm:
                    accelerator.clip_grad_norm_(model.parameters(), config.training.max_grad_norm)
                
                optimizer.step()
                lr_scheduler.step()
                optimizer.zero_grad(set_to_none=True)

                # 记录梯度范数 (可选)
                if (global_step + 1) % config.experiment.log_grad_norm_every == 0 and accelerator.is_main_process:
                    log_grad_norm(model, accelerator, global_step + 1)

        # *-------*-------*-------*-------*-------*-------*
        # Logging & Saving & Validation
        # *-------*-------*-------*-------*-------*-------*
        if accelerator.sync_gradients:
            global_step += 1
            
            batch_time_m.update(time.time() - end)
            end = time.time()

            # Logging
            if global_step % config.experiment.log_every == 0:
                avg_loss = accelerator.reduce(loss.detach(), reduction="mean")

                samples_per_second_per_gpu = (
                        accelerator.gradient_accumulation_steps * config.training.batch_size / batch_time_m.val
                )

                logs = {
                    "t_1": t_1,
                    "step_loss": avg_loss.item(),
                    "train_ppl": math.exp(avg_loss.item()),
                    "lr": lr_scheduler.get_last_lr()[0],
                    "samples/sec/gpu": samples_per_second_per_gpu,
                    "batch_time": batch_time_m.val,
                }
                accelerator.log(logs, step=global_step)

                if accelerator.is_main_process:
                    logger.info(
                        f"Step: {global_step} | "
                        f"T: {t_1} | "
                        f"Loss: {avg_loss.item():0.4f} | "
                        f"LR: {lr_scheduler.get_last_lr()[0]:0.6f} | "
                        f"Sec/Iter: {batch_time_m.val:0.4f}"
                    )

                batch_time_m.reset()
                data_time_m.reset()

            # Checkpointing
            if global_step % config.experiment.save_every == 0:
                save_checkpoint(model, config, accelerator, global_step)
            
            if global_step % config.experiment.save_hfmodel_every == 0:
                save_hf_model(model, tokenizer, config, accelerator, global_step)
                
            # Validation
            if global_step % config.experiment.val_every == 0:
                model.eval()
                validate(model, val_dataloader, diff_lm, accelerator, global_step)
                # if accelerator.is_main_process:
                #     pre_text, label_text = get_text(logits_pred=logits_pred[0], label_ids=label_ids[0], tokenizer=tokenizer)
                #     accelerator.print(f"pre_text: {pre_text}")
                #     accelerator.print(f"label_text: {label_text}")
                
                model.train() 

            if global_step >= config.training.max_train_steps:
                break

    accelerator.wait_for_everyone()
    save_hf_model(model, tokenizer, config, accelerator, "final")
    accelerator.end_training()


@torch.no_grad()
def validate(model, val_dataloader, diff_lm, accelerator, global_step):
    # 初始化统计变量
    local_total_loss_diff = torch.tensor(0.0, device=accelerator.device) # Diffusion Loss
    local_total_loss_ar = torch.tensor(0.0, device=accelerator.device)   # Standard AR Loss
    local_total_count = torch.tensor(0.0, device=accelerator.device)
    
    for step, batch in enumerate(val_dataloader):
        text_ids = batch["input_ids"][:, :-1].contiguous()
        current_batch_size = text_ids.size(0)

        _, v_sample = diff_lm.sample_v(text_ids)
        B, L = text_ids.shape
    
        v_sample = v_sample.to(accelerator.device)
        diffusion_attention_mask = get_selfless_mask(v_sample=v_sample, seq_len=L, device=accelerator.device)
        del v_sample

        loss_diff = model(
            X0_input_ids=text_ids,
            labels=text_ids,
            attention_mask=diffusion_attention_mask,
            calculate_likelihood=True
        ).loss
        
        local_total_loss_diff += loss_diff.detach() * current_batch_size
        
        AR_mask = get_selfless_ar_mask(seq_len=L, device=accelerator.device)
        loss_ar = model(
            X0_input_ids=text_ids,
            labels=text_ids,
            attention_mask=AR_mask,
            calculate_likelihood=True
        ).loss
        
        local_total_loss_ar += loss_ar.detach() * current_batch_size
        
        # 计数
        local_total_count += current_batch_size

    global_total_count = accelerator.reduce(local_total_count, reduction="sum")
    
    # 计算 Diffusion metrics
    global_total_loss_diff = accelerator.reduce(local_total_loss_diff, reduction="sum")
    avg_loss_diff = (global_total_loss_diff / global_total_count).item()
    ppl_diff = math.exp(avg_loss_diff)
    
    # 计算 AR metrics
    global_total_loss_ar = accelerator.reduce(local_total_loss_ar, reduction="sum")
    avg_loss_ar = (global_total_loss_ar / global_total_count).item()
    ppl_ar = math.exp(avg_loss_ar)
    
    # ==========================================
    # 4. Logging
    # ==========================================
    if accelerator.is_main_process:
        logs = {
            "val/loss_diff": avg_loss_diff,
            "val/ppl_diff": ppl_diff,
            "val/loss_ar": avg_loss_ar,
            "val/ppl_ar": ppl_ar
        }
        accelerator.log(logs, step=global_step)
        
        logger.info(
            f"[Validation] Step {global_step + 1} | "
            f"Diff Loss: {avg_loss_diff:.4f} (PPL: {ppl_diff:.2f}) | "
            f"AR Loss: {avg_loss_ar:.4f} (PPL: {ppl_ar:.2f}) | "
        )

    return avg_loss_diff, ppl_diff


if __name__ == "__main__":
    import warnings

    warnings.filterwarnings("error", message="None of the inputs have requires_grad=True")
    main() 